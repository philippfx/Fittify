import {UniqueIdentifier} from '../../common/UniqueIdentifier';

export class ExerciseForGet extends UniqueIdentifier<number> {
  public name: string;
}
