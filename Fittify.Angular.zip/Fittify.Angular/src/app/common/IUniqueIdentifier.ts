export interface IUniqueIdentifier<TId> {
  id: TId;
}
