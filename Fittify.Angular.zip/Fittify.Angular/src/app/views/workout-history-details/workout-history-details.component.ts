import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ff-workout-history-details',
  templateUrl: './workout-history-details.component.html',
  styleUrls: ['./workout-history-details.component.css']
})
export class WorkoutHistoryDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
