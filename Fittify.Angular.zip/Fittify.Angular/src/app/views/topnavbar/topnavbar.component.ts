import { Component } from '@angular/core';

@Component({
    selector: 'ff-navbar',
    templateUrl: './topnavbar.component.html',
    styleUrls: ['./topnavbar.component.css']
})

export class TopNavbarComponent {}
