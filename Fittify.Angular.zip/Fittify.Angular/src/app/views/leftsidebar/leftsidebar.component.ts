import { Component } from '@angular/core';

@Component({
    selector: 'ff-leftsidebar',
    templateUrl: './leftsidebar.component.html',
    styleUrls: ['./leftsidebar.component.css']
})

export class LeftSidebarComponent {}
