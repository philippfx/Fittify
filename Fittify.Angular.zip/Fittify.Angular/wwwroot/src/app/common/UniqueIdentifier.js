"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UniqueIdentifier = (function () {
    function UniqueIdentifier() {
    }
    return UniqueIdentifier;
}());
exports.UniqueIdentifier = UniqueIdentifier;
//# sourceMappingURL=UniqueIdentifier.js.map