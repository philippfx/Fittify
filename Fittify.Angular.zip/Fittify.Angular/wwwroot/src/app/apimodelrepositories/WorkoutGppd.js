"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var WorkoutGppd = (function () {
    function WorkoutGppd(_gppdFactory) {
        this._gppdFactory = _gppdFactory;
    }
    return WorkoutGppd;
}());
exports.WorkoutGppd = WorkoutGppd;
//# sourceMappingURL=WorkoutGppd.js.map